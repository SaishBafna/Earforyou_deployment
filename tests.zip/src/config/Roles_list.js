const ROLES_LIST = {
    Driver: 9797,
    Mechanic: 9696,
    Tower:9595,
    Agent:9494,
    Company:9393
  };
  
export default ROLES_LIST;