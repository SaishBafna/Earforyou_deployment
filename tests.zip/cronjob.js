// import cleanExpiredRecharges from "./src/controllers/Recharge/walletCron";

// (async () => {
//   await cleanExpiredRecharges();
//   console.log("Test run of cleanExpiredRecharges completed.");
// })();
